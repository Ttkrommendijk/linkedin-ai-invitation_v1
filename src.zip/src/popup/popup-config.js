function initConfigModule(deps = {}) {
  return globalThis.PopupConfigController.configure(deps);
}

globalThis.initConfigModule = initConfigModule;
