function initMessagesModule(_deps = {}) {
  const lifecycleController = globalThis.PopupLifecycleController || {};
  const chatController = globalThis.PopupChatController || {};

  const getOutreachStatusFromDbRow =
    lifecycleController.getOutreachStatusFromDbRow;

  const renderMessageTab = lifecycleController.renderMessageTab;

  const refreshChatHistoryFromActiveTab =
    chatController.refreshChatHistoryFromActiveTab;

  const fetchChatHistory = chatController.fetchChatHistory;

  function updateFirstMessageCopyIconVisibility() {}

  function updateFirstMessageSaveIconVisibility() {}

  function updateMessageTabControls() {}

  async function refreshMessagesTab() {
    return false;
  }

  async function onMessagesTabOpenedByUser() {
    return false;
  }

  const bindMessagesWorkflowEvents =
    chatController.bindChatHistoryEvents || (() => {});

  return {
    getOutreachStatusFromDbRow,
    renderMessageTab,
    refreshChatHistoryFromActiveTab,
    fetchChatHistory,
    updateFirstMessageCopyIconVisibility,
    updateFirstMessageSaveIconVisibility,
    updateMessageTabControls,
    refreshMessagesTab,
    onMessagesTabOpenedByUser,
    bindMessagesWorkflowEvents,
  };
}

globalThis.initMessagesModule = initMessagesModule;
