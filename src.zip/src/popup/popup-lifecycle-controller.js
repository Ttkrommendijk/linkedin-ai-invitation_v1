(function initPopupLifecycleController(globalObj) {
  function getLifecycleStatusValue(dbRow) {
    return (dbRow?.status || "").trim().toLowerCase();
  }

  function isPostSendMode() {
    const state = globalObj.PopupState || {};
    const status = getLifecycleStatusValue(state.dbInvitationRow);
    return (
      status === "first message sent" ||
      status === "first_message_sent" ||
      status === "message responded" ||
      status === "message_responded"
    );
  }

  function getOutreachStatusFromDbRow() {
    return "accepted";
  }

  function deriveLifecycleState(row) {
    if (!row) {
      return { key: "not_in_database", text: UI_TEXT.lifecycleNotInDatabase };
    }

    const status = (row.status || "").trim().toLowerCase();
    if (status === "generated") {
      return { key: "generated", text: UI_TEXT.lifecycleGenerated };
    }
    if (status === "invited") {
      return { key: "invited", text: UI_TEXT.lifecycleInvited };
    }
    if (status === "first message sent") {
      return {
        key: "first_message_sent",
        text: UI_TEXT.lifecycleFirstMessageSent,
      };
    }
    if ((row.first_message || "").trim()) {
      return {
        key: "first_message_generated",
        text: UI_TEXT.lifecycleFirstMessageGenerated,
      };
    }
    if (status) {
      return { key: "neutral", text: row.status };
    }
    return { key: "neutral", text: UI_TEXT.lifecycleInDatabase };
  }

  function setLifecycleBar() {}

  function updateGenerateFirstMessageButtonLabel() {
    return;
  }

  function setMessageTabModeUi() {}

  function renderMessageTab(_status) {}

  function applyLifecycleUiState(dbRow, { preserveTabs = false } = {}) {
    const dom = globalObj.PopupDom || {};
    const state = globalObj.PopupState || {};
    const generateBtn = document.getElementById("generate");

    if (!generateBtn) return;
    updateGenerateFirstMessageButtonLabel();

    generateBtn.disabled = false;

    const status = getLifecycleStatusValue(dbRow);
    const dbMessage = (dbRow?.message || "").trim();
    if (dbMessage) {
      dom.previewEl.textContent = dbMessage;
      globalObj.updateInviteCopyIconVisibility?.();
    }

    if (status === "generated") {
      if (!preserveTabs) {
        globalObj.setActiveTab?.("detail");
        globalObj.setDetailInnerTab?.("invite");
      }
      if (dbMessage) {
        dom.previewEl.textContent = dbMessage;
        globalObj.updateInviteCopyIconVisibility?.();
      }
      return;
    }

    if (status === "invited") {
      if (!preserveTabs) {
        globalObj.setActiveTab?.("detail");
        globalObj.setDetailInnerTab?.("invite");
      }
      if (dbMessage) {
        dom.previewEl.textContent = dbMessage;
        globalObj.updateInviteCopyIconVisibility?.();
      }
      generateBtn.disabled = true;
      return;
    }

    if (
      status === "first message sent" ||
      status === "first_message_sent" ||
      status === "message responded" ||
      status === "message_responded"
    ) {
      if (!preserveTabs) {
        globalObj.setActiveTab?.("detail");
        globalObj.setDetailInnerTab?.("first");
      }
      generateBtn.disabled = true;
      if (dbMessage) {
        dom.previewEl.textContent = dbMessage;
        globalObj.updateInviteCopyIconVisibility?.();
      }
    }

    globalObj.updateInviteCopyIconVisibility?.();

    if (
      status === "first message sent" ||
      status === "first_message_sent" ||
      status === "message responded" ||
      status === "message_responded" ||
      status === "accepted"
    ) {
      const dbFirstMessage = (dbRow?.first_message || "").trim();
      if (dbFirstMessage) {
        dom.firstMessagePreviewEl.textContent = dbFirstMessage;
        state.firstMessage = dbFirstMessage;
      }
    }
  }

  globalObj.PopupLifecycleController = Object.freeze({
    getLifecycleStatusValue,
    isPostSendMode,
    getOutreachStatusFromDbRow,
    deriveLifecycleState,
    setLifecycleBar,
    applyLifecycleUiState,
    updateGenerateFirstMessageButtonLabel,
    renderMessageTab,
    setMessageTabModeUi,
  });
})(typeof globalThis !== "undefined" ? globalThis : self);
