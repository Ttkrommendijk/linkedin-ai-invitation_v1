try {
  importScripts("../shared/utils.js");
} catch (_e) {
  // Optional shared helper; background keeps local fallbacks.
}
try {
  importScripts("../shared/runtime-utils.js");
} catch (_e) {
  // Optional shared helper; background keeps local fallbacks.
}
try {
  importScripts("../shared/logging-utils.js");
} catch (_e) {
  // Optional shared helper; background keeps local fallbacks.
}

try {
  importScripts("../prompts.js");
} catch (_e) {
  // Optional shared helper; background keeps local fallbacks.
}

try {
  importScripts("./navigation-watcher.js");
} catch (_e) {
  // Optional background helper; background keeps working without it.
}
try {
  importScripts("./chrome-utils.js");
} catch (_e) {
  // Optional background helper; background keeps local fallbacks.
}
try {
  importScripts("./router-utils.js");
} catch (_e) {
  // Optional background helper; background keeps local fallbacks.
}
try {
  importScripts("./workflow-service.js");
} catch (_e) {
  // Optional background helper; background keeps local fallbacks.
}

try {
  importScripts("./openai-service.js");
} catch (e) {
  console.error("[LEF] failed to import openai-service.js", e);
}

try {
  importScripts("./supabase-service.js");
  importScripts("./supabase-invitations.js");
  importScripts("./supabase-company.js");
  importScripts("./supabase-prompts.js");
  importScripts("./supabase-campaigns.js");
  importScripts("./supabase-overview.js");
} catch (e) {
  console.error("[LEF] failed to import supabase modules", e);
}

if (globalThis.LEFNavigationWatcher?.initNavigationWatcher) {
  globalThis.LEFNavigationWatcher.initNavigationWatcher();
}

const LEF_UTILS = globalThis.LEFUtils || {};
const LEF_RUNTIME_UTILS = globalThis.LEFRuntimeUtils || LEF_UTILS || {};
const LEF_LOGGING = globalThis.LEFLoggingUtils || {};

const LEF_OPENAI = globalThis.LEFOpenAIService || {};
const LEF_CHROME_UTILS = globalThis.LEFChromeUtils || {};
const LEF_ROUTER = globalThis.LEFRouterUtils || {};
const LEF_WORKFLOW = globalThis.LEFWorkflowService || {};

const LEF_SUPABASE = globalThis.LEFSupabaseService || {};
const LEF_SUPABASE_INVITATIONS = globalThis.LEFSupabaseInvitations || {};
const LEF_SUPABASE_COMPANY = globalThis.LEFSupabaseCompany || {};
const LEF_SUPABASE_PROMPTS = globalThis.LEFSupabasePrompts || {};
const LEF_SUPABASE_CAMPAIGNS = globalThis.LEFSupabaseCampaigns || {};
const LEF_SUPABASE_OVERVIEW = globalThis.LEFSupabaseOverview || {};

const fetchWithTimeout = LEF_OPENAI.fetchWithTimeout;
const createProviderHttpError = LEF_OPENAI.createProviderHttpError;

const readSupabaseSessionFromStorage =
  LEF_SUPABASE.readSupabaseSessionFromStorage;

const clearSupabaseSession = LEF_SUPABASE.clearSupabaseSession;

const isSupabaseSessionExpired = LEF_SUPABASE.isSupabaseSessionExpired;

const fetchSupabaseAuthUser = LEF_SUPABASE.fetchSupabaseAuthUser;

const refreshSupabaseSession = LEF_SUPABASE.refreshSupabaseSession;

const normalizeError = LEF_RUNTIME_UTILS.normalizeError;
const normalizeProfileField = LEF_RUNTIME_UTILS.normalizeProfileField;
const isLinkedInProfileLikeUrl = LEF_RUNTIME_UTILS.isLinkedInProfileLikeUrl;
const emitUiStatus = LEF_CHROME_UTILS.emitUiStatus;
const getActiveTabInCurrentWindow =
  LEF_CHROME_UTILS.getActiveTabInCurrentWindow;
const sendMessageToTab = LEF_CHROME_UTILS.sendMessageToTab;
const handleAsyncMessage = LEF_ROUTER.handleAsyncMessage;
const withUiStatus = LEF_ROUTER.withUiStatus;
const debug = LEF_LOGGING.debug;

const STORAGE_KEY_SUPABASE_SESSION = "lef_supabase_session_v1";
const STORAGE_KEY_SUPABASE_URL = "supabase_url";
const DEFAULT_SUPABASE_URL = "https://nkhujuqjnbzsfqyqfndc.supabase.co";

let cachedSupabaseSession = null;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  const req = msg || {};
  debug("onMessage:", msg?.type);
  console.log("[LEF][chat] received type", req.type);

  if (msg?.type === "GET_ACTIVE_TAB_CONTEXT") {
    (async () => {
      await handleAsyncMessage(sendResponse, async () => {
        const tab = await getActiveTabInCurrentWindow();
        return {
          ok: true,
          data: {
            tabId: Number.isInteger(tab?.id) ? tab.id : null,
            url: tab?.url || "",
          },
        };
      });
    })();
    return true;
  }

  if (msg?.type === "SCRAPE_PROFILE_CONTEXT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          const tab = await getActiveTabInCurrentWindow();
          if (!Number.isInteger(tab?.id)) {
            return {
              ok: false,
              error: normalizeError(
                "No active tab found.",
                "EXTRACTION_FAILED",
              ),
            };
          }
          const resp = await sendMessageToTab(tab.id, {
            type: "EXTRACT_PROFILE_CONTEXT",
          });
          if (!resp?.ok || !resp?.profile) {
            const errorMessage =
              typeof resp?.error === "string"
                ? resp.error
                : resp?.error?.message || "profile extraction failed";
            return {
              ok: false,
              error: normalizeError(errorMessage, "EXTRACTION_FAILED"),
            };
          }
          return { ok: true, data: { profile: resp.profile } };
        },
        { errorCode: "EXTRACTION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "FETCH_CHAT_HISTORY") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          const tab = await getActiveTabInCurrentWindow();
          if (!Number.isInteger(tab?.id)) {
            return {
              ok: true,
              data: {
                messages: [],
                chat_history: "",
                meta: { no_active_tab: true },
              },
            };
          }
          const reqId = String(msg?.payload?.reqId || `chat_${Date.now()}`);
          const resp = await sendMessageToTab(tab.id, {
            type: "EXTRACT_CHAT_HISTORY",
            reqId,
          });
          if (!resp?.ok) {
            return {
              ok: true,
              data: { messages: [], chat_history: "", meta: resp?.meta || {} },
            };
          }
          const messages = Array.isArray(resp?.messages) ? resp.messages : [];
          const chat_history = messages
            .map((m) => (m?.text || "").toString().trim())
            .filter(Boolean)
            .join("\n");
          return {
            ok: true,
            data: { messages, chat_history, meta: resp?.meta || {} },
          };
        },
        { errorCode: "EXTRACTION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "OPEN_LINKEDIN_URL") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () => LEF_CHROME_UTILS.openLinkedInUrl(msg?.payload || {}),
        { errorCode: "UNKNOWN_ERROR" },
      );
    })();
    return true;
  }

  if (msg?.type === "GENERATE_INVITE") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Sending to LLM\u2026", async () => {
            const generation =
              await globalThis.LEFOpenAIService.callOpenAIInviteGeneration(
                msg.payload,
              );
            return {
              ok: true,
              invite_text: generation.invite_text,
            };
          }),
        { errorCode: "GENERATION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "ENRICH_PROFILE") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Sending to LLM\u2026", async () => {
            const extraction = await LEF_WORKFLOW.enrichProfile(
              msg.payload || {},
            );
            return {
              ok: true,
              company: extraction.company,
              headline: extraction.headline,
              language: extraction.language,
            };
          }),
        { errorCode: "GENERATION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "ENRICH_COMPANY_PROFILE") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Sending to LLM\u2026", async () => {
            try {
              const extraction = await LEF_WORKFLOW.enrichCompanyProfile(
                msg.payload || {},
              );
              return { ok: true, ...extraction };
            } catch (e) {
              console.log("[LEF][company save failed]", e);
              throw e;
            }
          }),
        { errorCode: "GENERATION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "GENERATE_FREE_PROMPT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Sending to LLM\u2026", async () => {
            const text = await LEF_OPENAI.callOpenAIFreePrompt(
              msg.payload || {},
            );
            return { ok: true, text };
          }),
        { errorCode: "GENERATION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "SUPABASE_AUTH_SIGNUP") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          const result = await callSupabaseAuthSignup(msg?.payload || {});
          return {
            ok: true,
            session: result.session || null,
            message: result.message || "Signup successful.",
          };
        },
        { errorCode: "SUPABASE_AUTH_SIGNUP_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "SUPABASE_AUTH_LOGIN") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          const session = await callSupabaseAuthLogin(msg?.payload || {});
          return { ok: true, session };
        },
        { errorCode: "SUPABASE_AUTH_LOGIN_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "SUPABASE_AUTH_RESET_PASSWORD") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          await callSupabaseAuthResetPassword(msg?.payload || {});
          return { ok: true };
        },
        { errorCode: "SUPABASE_AUTH_RESET_PASSWORD_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "SUPABASE_AUTH_LOGOUT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          await callSupabaseAuthLogout();
          return { ok: true };
        },
        { errorCode: "SUPABASE_AUTH_LOGOUT_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "SUPABASE_AUTH_GET_SESSION") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          let session = await readSupabaseSessionFromStorage();
          if (session && isSupabaseSessionExpired(session)) {
            try {
              session = await refreshSupabaseSession(session);
            } catch (_e) {
              await clearSupabaseSession();
              session = null;
            }
          }
          return { ok: true, session };
        },
        { errorCode: "SUPABASE_AUTH_SESSION_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPSERT_GENERATED") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Communicating to database\u2026", async () => {
            await supabaseUpsertInvitation(msg.payload);
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPSERT_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPDATE_FIRST_MESSAGE") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseUpdateFirstMessage(
              msg.payload,
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_MARK_STATUS") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Communicating to database\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseMarkStatus(msg.payload);
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_MARK_FIRST_MESSAGE_SENT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Communicating to database\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseMarkFirstMessageSent(
              msg.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_SET_STATUS_ONLY") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Communicating to database\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseSetStatusOnly(msg.payload);
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_SET_ACCEPTED_AT_NOW") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Communicating to database\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseSetAcceptedAtNow(
              msg.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_CLEAR_ACCEPTED_AT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Communicating to database\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseClearAcceptedAt(
              msg.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_INCREMENT_MESSAGE_COUNT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseIncrementMessageCount(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_SET_MESSAGE_COUNT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseSetMessageCount(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPDATE_PROFILE_DETAILS_ONLY") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseUpdateProfileDetailsOnly(
              msg.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPDATE_PROFILE_FIELDS") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseUpdateProfileFields(
              msg.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_GET_INVITATION") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const row =
              await LEF_SUPABASE_INVITATIONS.supabaseGetInvitationByLinkedinUrl(
                msg?.payload?.linkedin_url,
              );
            return { ok: true, row };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_FIND_COMPANY_BY_NAME") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const company =
              await LEF_SUPABASE_COMPANY.supabaseFindCompanyByName(
                msg?.payload || {},
              );
            return { ok: true, company };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_GET_COMPANY_BY_ID") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const company = await LEF_SUPABASE_COMPANY.supabaseGetCompanyById(
              msg?.payload || {},
            );
            return { ok: true, company };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_GET_COMPANY_BY_LINKEDIN_ID") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const company =
              await LEF_SUPABASE_COMPANY.supabaseGetCompanyByLinkedinId(
                msg?.payload || {},
              );
            return { ok: true, company };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_LIST_INVITATIONS_BY_COMPANY") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const rows =
              await LEF_SUPABASE_COMPANY.supabaseListInvitationsByCompany(
                msg?.payload || {},
              );
            return { ok: true, rows };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_SEARCH_COMPANIES") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const companies =
              await LEF_SUPABASE_COMPANY.supabaseSearchCompanies(
                msg?.payload || {},
              );
            return { ok: true, companies };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_SEARCH_UNLINKED_COMPANIES") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            timingLog("db_search_unlinked_companies_called", {
              term: normalizeProfileField(msg?.payload?.term),
              limit: msg?.payload?.limit,
            });
            console.log("[LEF][company search]", {
              ts: Date.now(),
              term: normalizeProfileField(msg?.payload?.term),
              limit: msg?.payload?.limit,
            });
            const companies =
              await LEF_SUPABASE_COMPANY.supabaseSearchUnlinkedCompanies(
                msg?.payload || {},
              );
            return { ok: true, companies };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_CONFIRM_COMPANY_LINK") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_COMPANY.supabaseConfirmCompanyLink(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPSERT_COMPANY_PROFILE") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            try {
              const company = await LEF_WORKFLOW.upsertCompanyProfile(
                msg?.payload || {},
              );
              return { ok: true, company };
            } catch (e) {
              console.log("[LEF][company save failed]", e);
              throw e;
            }
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPDATE_COMPANY_BY_ID") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            try {
              const company = await LEF_WORKFLOW.updateCompanyById(
                msg?.payload || {},
              );
              return { ok: true, company };
            } catch (e) {
              console.log("[LEF][company save failed]", e);
              throw e;
            }
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "GET_PROMPTS") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const prompts = await LEF_SUPABASE_PROMPTS.supabaseGetPrompts();
            return { ok: true, prompts };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "CREATE_PROMPT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            const prompt = await LEF_SUPABASE_PROMPTS.supabaseCreatePrompt(
              msg?.payload || {},
            );
            return { ok: true, prompt };
          }),
        { errorCode: "SUPABASE_UPSERT_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "UPDATE_PROMPT") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            const prompt = await LEF_SUPABASE_PROMPTS.supabaseUpdatePrompt(
              msg?.payload || {},
            );
            return { ok: true, prompt };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "UPDATE_PROMPT_NAME") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            const prompt = await LEF_SUPABASE_PROMPTS.supabaseUpdatePromptName(
              msg?.payload || {},
            );
            return { ok: true, prompt };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_LIST_CAMPAIGNS") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const campaign_rows =
              await LEF_SUPABASE_CAMPAIGNS.supabaseListCampaigns();
            const campaigns = campaign_rows
              .map((row) => normalizeProfileField(row?.campaign_name))
              .filter(Boolean);
            return { ok: true, campaigns, campaign_rows };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_CREATE_CAMPAIGN") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            const campaign =
              await LEF_SUPABASE_CAMPAIGNS.supabaseCreateCampaign(
                msg?.payload || {},
              );
            return { ok: true, campaign };
          }),
        { errorCode: "SUPABASE_UPSERT_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UPDATE_CAMPAIGN") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            const campaign =
              await LEF_SUPABASE_CAMPAIGNS.supabaseUpdateCampaign(
                msg?.payload || {},
              );
            return { ok: true, campaign };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_LIST_PERSON_CAMPAIGNS") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const rows =
              await LEF_SUPABASE_CAMPAIGNS.supabaseListPersonCampaigns(
                msg?.payload || {},
              );
            return { ok: true, rows };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_LINK_PERSON_CAMPAIGN") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_CAMPAIGNS.supabaseLinkPersonCampaign(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPSERT_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_UNLINK_PERSON_CAMPAIGN") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_CAMPAIGNS.supabaseUnlinkPersonCampaign(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_LIST_INVITATIONS_OVERVIEW") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const result =
              await LEF_SUPABASE_OVERVIEW.supabaseListInvitationsOverview(
                msg?.payload || {},
              );
            return { ok: true, rows: result.rows, total: result.total };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_LIST_COMPANIES") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Fetching\u2026", async () => {
            const result =
              await LEF_SUPABASE_COMPANY.supabaseListCompaniesOverview(
                msg?.payload || {},
              );
            return { ok: true, rows: result.rows, total: result.total };
          }),
        { errorCode: "SUPABASE_GET_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_ARCHIVE_COMPANY") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_COMPANY.supabaseArchiveCompany(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_ARCHIVE_INVITATION") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseArchiveInvitation(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "DB_SET_ARCHIVED") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        () =>
          withUiStatus("Updating\u2026", async () => {
            await LEF_SUPABASE_INVITATIONS.supabaseSetArchived(
              msg?.payload || {},
            );
            return { ok: true };
          }),
        { errorCode: "SUPABASE_UPDATE_FAILED" },
      );
    })();
    return true;
  }

  if (msg?.type === "SP_REQUEST_REFRESH_SIGNAL") {
    (async () => {
      await handleAsyncMessage(
        sendResponse,
        async () => {
          const [tab] = await chrome.tabs.query({
            active: true,
            currentWindow: true,
          });
          const url = tab?.url || "";
          if (
            tab?.id &&
            globalThis.LEFNavigationWatcher?.scheduleSidePanelRefresh &&
            isLinkedInProfileLikeUrl(url)
          ) {
            globalThis.LEFNavigationWatcher.scheduleSidePanelRefresh(
              tab.id,
              url,
              "sidepanel.request",
              { force: true },
            );
          }
          return { ok: true };
        },
        { errorCode: "UNKNOWN_ERROR" },
      );
    })();
    return true;
  }

  console.error("[LEF][chat] unknown type", req.type);
  sendResponse({
    ok: false,
    error: normalizeError("unknown_message_type", "UNKNOWN_MESSAGE_TYPE"),
  });
  return false;
});
