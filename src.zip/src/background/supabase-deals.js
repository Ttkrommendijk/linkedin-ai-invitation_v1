(function initSupabaseDeals(globalObj) {
  const LEF_UTILS = globalObj.LEFUtils || {};
  const LEF_SUPABASE = globalObj.LEFSupabaseService || {};
  const LEF_OPENAI = globalObj.LEFOpenAIService || {};

  const normalizeProfileField =
    typeof LEF_UTILS.normalizeProfileField === "function"
      ? LEF_UTILS.normalizeProfileField
      : (value) => (value == null ? "" : String(value).trim());

  const getSupabaseRequestContext = LEF_SUPABASE.getSupabaseRequestContext;
  const fetchWithTimeout = LEF_OPENAI.fetchWithTimeout;
  const createProviderHttpError = LEF_OPENAI.createProviderHttpError;

  function buildQuery(params) {
    return Object.entries(params)
      .filter(([, value]) => value !== undefined && value !== null && value !== "")
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
      .join("&");
  }

  async function supabaseListDeals(payload = {}) {
    const { supabaseUrl, supabaseAnonKey, accessToken } =
      await getSupabaseRequestContext();
    const companyId = normalizeProfileField(payload.company_id);
    if (!companyId) return [];

    const params = {
      select: "deal_id,created_at,deal_name,deal_description,deal_value,company_id,deal_phase",
      company_id: `eq.${companyId}`,
      order: "created_at.desc",
    };

    const url = `${supabaseUrl}/rest/v1/deal?${buildQuery(params)}`;
    const res = await fetchWithTimeout(
      url,
      {
        method: "GET",
        headers: {
          apikey: supabaseAnonKey,
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
      },
      15000,
      "Supabase request",
    );
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw createProviderHttpError("supabase", res.status, txt);
    }
    const rows = await res.json();
    return Array.isArray(rows) ? rows : [];
  }


  async function supabaseCreateDeal(payload = {}) {
    const { supabaseUrl, supabaseAnonKey, accessToken } =
      await getSupabaseRequestContext();
    const companyId = normalizeProfileField(payload.company_id);
    const dealName = normalizeProfileField(payload.deal_name);
    const dealPhase = normalizeProfileField(payload.deal_phase);
    if (!companyId) throw new Error("company_id is required to create a deal.");
    if (!dealName) throw new Error("deal_name is required to create a deal.");
    if (!dealPhase) throw new Error("deal_phase is required to create a deal.");

    const row = {
      deal_name: dealName,
      deal_description: normalizeProfileField(payload.deal_description) || null,
      deal_value:
        payload.deal_value === null || payload.deal_value === undefined || payload.deal_value === ""
          ? null
          : Number(payload.deal_value),
      company_id: companyId,
      deal_phase: dealPhase,
    };

    const url = `${supabaseUrl}/rest/v1/deal`;
    const res = await fetchWithTimeout(
      url,
      {
        method: "POST",
        headers: {
          apikey: supabaseAnonKey,
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          Prefer: "return=representation",
        },
        body: JSON.stringify(row),
      },
      15000,
      "Supabase request",
    );
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw createProviderHttpError("supabase", res.status, txt);
    }
    const rows = await res.json();
    return Array.isArray(rows) ? rows[0] || null : rows || null;
  }


  globalObj.LEFSupabaseDeals = Object.freeze({
    supabaseListDeals,
    supabaseCreateDeal,
  });
})(typeof globalThis !== "undefined" ? globalThis : self);
